﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.SqlClient;
using System.Data;
using System.Web.UI.WebControls;

namespace troopspage
{
    public partial class Sign_up_or_Log_in : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
          
        }

        protected void BtnMemID_Click(object sender, EventArgs e)
        {



        }

        protected void BtnRegister_Click(object sender, EventArgs e)
        {
            String conString2 = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = goodies; Integrated Security = SSPI";
            SqlConnection con2 = new SqlConnection(conString2);

            String cmdString2 = "INSERT INTO [users] (userName, userPassword) VALUES ( @Uname, @uPass)";
            SqlCommand cmd2 = new SqlCommand(cmdString2, con2);

            SqlParameter paramC1 = new SqlParameter();
            paramC1.ParameterName = "@Uname";
            paramC1.Value = TxtBxUserID.Text;
            cmd2.Parameters.Add(paramC1);

            SqlParameter paramC2 = new SqlParameter();
            paramC2.ParameterName = "@Upass";
            paramC2.Value = TxtBxPassword.Text;
            cmd2.Parameters.Add(paramC2);

            int added = 0;

            try
            {
                con2.Open();
                added = cmd2.ExecuteNonQuery();
                LblAdded.Text += "You have been added. Enjoy our group page!" + added.ToString();
            }
            finally
            {
                con2.Close();
            }


        }


        protected void RdBtnVol_CheckedChanged(object sender, EventArgs e)
        {
            BtnRegister.Visible = false;
            BtnRegDon.Visible = false;
            BtnRegVol.Visible = true;
            RdBtnVis.Checked = false;
            RdBtnDonor.Checked = false;
            TxtBxUserID.Visible = true;
            LblUserID.Visible = true;
            TxtBxPassword.Visible = true;
            LblUserPW.Visible = true;
            TxtBxVerify.Visible = true;
            LblVerify.Visible = true;
            TxtBxVolFirst.Visible = true;
            LblVolFirst.Visible = true;
            TxtBxVolLast.Visible = true;
            LblVolLast.Visible = true;
            TxtBxVolEmail.Visible = true;
            LblVolEmail.Visible = true;
            TxtBxVolPhone.Visible = true;
            LblVolPhone.Visible = true;

            TxtBxDonAdd.Visible = false;
            LblDonAdd.Visible = false;
            TxtBxDonApt.Visible = false;
            LblDonApt.Visible = false;
            TxtBxDonCity.Visible = false;
            LblDonCity.Visible = false;
            TxtBxDonCo.Visible = false;
            LblDonComp.Visible = false;
            TxtBxDonFirst.Visible = false;
            LblDonorFirst.Visible = false;
            TxtBxDonInit.Visible = false;
            LblDonInit.Visible = false;
            TxtBxDonLast.Visible = false;
            LblDonLast.Visible = false;
            TxtBxDonState.Visible = false;
            LblDonState.Visible = false;
            TxtBxDonZip.Visible = false;
            LblDonZip.Visible = false;
        }

        protected void RdBtnVis_CheckedChanged(object sender, EventArgs e)
        {
            BtnRegVol.Visible = false;
            BtnRegDon.Visible = false;
            BtnRegister.Visible = true;
            RdBtnDonor.Checked = false;
            RdBtnVol.Checked = false;
            TxtBxUserID.Visible = true;
            LblUserID.Visible = true;
            TxtBxPassword.Visible = true;
            LblUserPW.Visible = true;
            TxtBxVerify.Visible = true;
            LblVerify.Visible = true;

            TxtBxDonAdd.Visible = false;
            LblDonAdd.Visible = false;
            TxtBxDonApt.Visible = false;
            LblDonApt.Visible = false;
            TxtBxDonCity.Visible = false;
            LblDonCity.Visible = false;
            TxtBxDonCo.Visible = false;
            LblDonComp.Visible = false;
            TxtBxDonFirst.Visible = false;
            LblDonorFirst.Visible = false;
            TxtBxDonInit.Visible = false;
            LblDonInit.Visible = false;
            TxtBxDonLast.Visible = false;
            LblDonLast.Visible = false;
            TxtBxDonState.Visible = false;
            LblDonState.Visible = false;
            TxtBxDonZip.Visible = false;
            LblDonZip.Visible = false;
            

            TxtBxVolFirst.Visible = false;
            LblVolFirst.Visible = false;
            TxtBxVolLast.Visible = false;
            LblVolLast.Visible = false;
            TxtBxVolEmail.Visible = false;
            LblVolEmail.Visible =false;
            TxtBxVolPhone.Visible = false;
            LblVolPhone.Visible = false;
        }

        protected void RdBtnDonor_CheckedChanged(object sender, EventArgs e)
        {
            BtnRegVol.Visible = false;
            BtnRegister.Visible = false;
            BtnRegDon.Visible = true;
            RdBtnVis.Checked = false;
            RdBtnVol.Checked = false;
            TxtBxUserID.Visible = true;
            LblUserID.Visible = true;
            TxtBxPassword.Visible = true;
            LblUserPW.Visible = true;
            TxtBxVerify.Visible = true;
            LblVerify.Visible = true;
            TxtBxDonAdd.Visible = true;
            LblDonAdd.Visible = true;
            TxtBxDonApt.Visible = true;
            LblDonApt.Visible = true;
            TxtBxDonCity.Visible = true;
            LblDonCity.Visible = true;
            TxtBxDonCo.Visible = true;
            LblDonComp.Visible = true;
            TxtBxDonFirst.Visible = true;
            LblDonorFirst.Visible = true;
            TxtBxDonInit.Visible = true;
            LblDonInit.Visible = true;
            TxtBxDonLast.Visible = true;
            LblDonLast.Visible = true;
            TxtBxDonState.Visible = true;
            LblDonState.Visible = true;
            TxtBxDonZip.Visible = true;
            LblDonZip.Visible = true;
           

            TxtBxVolFirst.Visible = false;
            LblVolFirst.Visible = false;
            TxtBxVolLast.Visible = false;
            LblVolLast.Visible = false;
            TxtBxVolEmail.Visible = false;
            LblVolEmail.Visible = false;
            TxtBxVolPhone.Visible = false;
            LblVolPhone.Visible = false;
        }

        protected void BtnRegDon_Click(object sender, EventArgs e)
        {
            String conString3 = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = goodies; Integrated Security = SSPI";
            SqlConnection con3 = new SqlConnection(conString3);

            String cmdString3 = "INSERT INTO [users] (userName, userPassword) VALUES ( @Uname, @uPass)";
            SqlCommand cmd3 = new SqlCommand(cmdString3, con3);

            SqlParameter paramC1 = new SqlParameter();
            paramC1.ParameterName = "@Uname";
            paramC1.Value = TxtBxUserID.Text;
            cmd3.Parameters.Add(paramC1);

            SqlParameter paramC2 = new SqlParameter();
            paramC2.ParameterName = "@Upass";
            paramC2.Value = TxtBxPassword.Text;
            cmd3.Parameters.Add(paramC2);

            String cmdString4 = "INSERT INTO [donor] (donorFName, donorMInitial, donorLName, donorCompanyName, donorAddress, donorApt, donorCity, donorState, donorZip) VALUES (@donfirst, @donmid, @donlast, @doncomp, @donadd, @donapt, @doncity, @donstate, @donzip)";
            SqlCommand cmd4 = new SqlCommand(cmdString4, con3);


            SqlParameter paramC3 = new SqlParameter();
            paramC3.ParameterName = "@donfirst";
            paramC3.Value = TxtBxDonFirst.Text;
            cmd4.Parameters.Add(paramC3);

            SqlParameter paramC4 = new SqlParameter();
            paramC4.ParameterName = "@donmid";
            paramC4.Value = TxtBxDonInit.Text;
            cmd4.Parameters.Add(paramC4);

            SqlParameter paramC5 = new SqlParameter();
            paramC5.ParameterName = "@donlast";
            paramC5.Value = TxtBxDonLast.Text;
            cmd4.Parameters.Add(paramC5);

            SqlParameter paramC6 = new SqlParameter();
            paramC6.ParameterName = "@doncomp";
            paramC6.Value = TxtBxDonCo.Text;
            cmd4.Parameters.Add(paramC6);

            SqlParameter paramC7 = new SqlParameter();
            paramC7.ParameterName = "@donadd";
            paramC7.Value = TxtBxDonAdd.Text;
            cmd4.Parameters.Add(paramC7);

            SqlParameter paramC8 = new SqlParameter();
            paramC8.ParameterName = "@donapt";
            paramC8.Value = TxtBxDonApt.Text;
            cmd4.Parameters.Add(paramC8);

            SqlParameter paramC9 = new SqlParameter();
            paramC9.ParameterName = "@doncity";
            paramC9.Value = TxtBxDonCity.Text;
            cmd4.Parameters.Add(paramC9);

            SqlParameter paramC10 = new SqlParameter();
            paramC10.ParameterName = "@donstate";
            paramC10.Value = TxtBxDonState.Text;
            cmd4.Parameters.Add(paramC10);

            SqlParameter paramC11 = new SqlParameter();
            paramC11.ParameterName = "@donzip";
            paramC11.Value = TxtBxDonZip.Text;
            cmd4.Parameters.Add(paramC11);

            int added = 0;
            int added2 = 0;

            try
            {
                con3.Open();
                added = cmd3.ExecuteNonQuery();
                added2 = cmd4.ExecuteNonQuery();
                LblAdded.Text += "You have been added as a donor. Enjoy our group page!" + added.ToString();
            }
            finally
            {
                con3.Close();
                
            }
        }

        protected void BtnRegVol_Click(object sender, EventArgs e)
        {
            String conString5 = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = goodies; Integrated Security = SSPI";
            SqlConnection con5 = new SqlConnection(conString5);

            String cmdString5 = "INSERT INTO [users] (userName, userPassword) VALUES ( @Uname, @uPass)";
            SqlCommand cmd5 = new SqlCommand(cmdString5, con5);

            SqlParameter paramC1 = new SqlParameter();
            paramC1.ParameterName = "@Uname";
            paramC1.Value = TxtBxUserID.Text;
            cmd5.Parameters.Add(paramC1);

            SqlParameter paramC2 = new SqlParameter();
            paramC2.ParameterName = "@Upass";
            paramC2.Value = TxtBxPassword.Text;
            cmd5.Parameters.Add(paramC2);

            String cmdString6 = "INSERT INTO [volunteer] (volunteerFName, volunteerLName, volunteerEmail, volunteerPhone) VALUES ( @volfirst, @vollast, @volemail, @volphone)";
            SqlCommand cmd6 = new SqlCommand(cmdString6, con5);

            SqlParameter paramC3 = new SqlParameter();
            paramC3.ParameterName = "@volfirst";
            paramC3.Value = TxtBxVolFirst.Text;
            cmd6.Parameters.Add(paramC3);

            SqlParameter paramC4 = new SqlParameter();
            paramC4.ParameterName = "@vollast";
            paramC4.Value = TxtBxVolLast.Text;
            cmd6.Parameters.Add(paramC4);

            SqlParameter paramC5 = new SqlParameter();
            paramC5.ParameterName = "@volemail";
            paramC5.Value = TxtBxVolEmail.Text;
            cmd6.Parameters.Add(paramC5);

            SqlParameter paramC6 = new SqlParameter();
            paramC6.ParameterName = "@volphone";
            paramC6.Value = TxtBxVolPhone.Text;
            cmd6.Parameters.Add(paramC6);

            int added = 0;
            int added2 = 0;

            try
            {
                con5.Open();
                added = cmd5.ExecuteNonQuery();
                added2 = cmd6.ExecuteNonQuery();
                LblAdded.Text += "You have been added as a volunteer. Enjoy our group page!" + added.ToString();
            }
            finally
            {
                con5.Close();
            }
        }
    }
}