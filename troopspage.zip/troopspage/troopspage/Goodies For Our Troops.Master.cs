﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace troopspage
{
    public partial class Goodies_For_Our_Troops : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
          // var menu = Page.Master.FindControl("Menu2") as Menu;
           //if (menu != null)
          // {
            //  menu.Items.Remove(menu.FindItem("Maintain User Info"));
           //   menu.Items.Remove(menu.FindItem("Make a Deposit"));
            //  menu.Items.Remove(menu.FindItem("Maintain Photos"));
            //  menu.Items.Remove(menu.FindItem("Maintain Troop List"));
            //  menu.Items.Remove(menu.FindItem("Maintain Photos"));
            //  menu.Items.Remove(menu.FindItem("Maintain Public Content"));
           // }
        }
    }
}