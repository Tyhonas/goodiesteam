﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Web.UI.WebControls;

namespace troopspage
{
    public partial class Add_Troop : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BtnAddTroop_Click(object sender, EventArgs e)
        {
            
                String conString1 = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = goodies; Integrated Security = SSPI";
                SqlConnection con1 = new SqlConnection(conString1);

                String cmdString1 = "INSERT INTO [troop] (troopTitle, troopFName, troopMInitial, troopLName, troopComments, troopHometown, troopBranch, troopCountry, troopAddress1, troopAddress2, troopAddress3, troopAddress4, troopAddress5, troopCity, troopState, troopZip, userID), VALUES (@Ttitle, @Tfirst, @Tmid, @Tlast, @Tcomm, @Thome, @Tbranch, @Tcountry, @Tadd1, @Tadd2, @Tadd3, @Tadd4, @Tadd5, @Tcity, @Tstate, @Tzip, @Uid)";
                SqlCommand cmd1 = new SqlCommand(cmdString1, con1);

            SqlParameter paramC1 = new SqlParameter();
            paramC1.ParameterName = "@Ttitle";
            paramC1.Value = TxtBxTroopTitle.Text;
            cmd1.Parameters.Add(paramC1);

            SqlParameter paramC2 = new SqlParameter();
            paramC2.ParameterName = "@Tfirst";
            paramC2.Value = TxtBxTroopFirst.Text;
            cmd1.Parameters.Add(paramC2);

            SqlParameter paramC3 = new SqlParameter();
            paramC3.ParameterName = "@Tmid";
            paramC3.Value = TxtBxTroopInit.Text;
            cmd1.Parameters.Add(paramC3);

            SqlParameter paramC4 = new SqlParameter();
            paramC4.ParameterName = "@Tlast";
            paramC4.Value = TxtBxTroopLast.Text;
            cmd1.Parameters.Add(paramC4);

            SqlParameter paramC5 = new SqlParameter();
            paramC5.ParameterName = "@Tcomm";
            paramC5.Value = TxtBxTroopComment.Text;
            cmd1.Parameters.Add(paramC5);

            SqlParameter paramC6 = new SqlParameter();
            paramC6.ParameterName = "@Thome";
            paramC6.Value = TxtBxTroopHome.Text;
            cmd1.Parameters.Add(paramC6);

            SqlParameter paramC7 = new SqlParameter();
            paramC7.ParameterName = "@Tbrach";
            paramC7.Value = TxtBxTroopBranch.Text;
            cmd1.Parameters.Add(paramC7);

            SqlParameter paramC8 = new SqlParameter();
            paramC8.ParameterName = "@Tcountry";
            paramC8.Value = TxtBxTroopCountry.Text;
            cmd1.Parameters.Add(paramC8);

            SqlParameter paramC9 = new SqlParameter();
            paramC9.ParameterName = "@Tadd1";
            paramC9.Value = TxtBxTroopAdd1.Text;
            cmd1.Parameters.Add(paramC9);

            SqlParameter paramC10 = new SqlParameter();
            paramC10.ParameterName = "@Tadd2";
            paramC10.Value = TxtBxTroopAdd2.Text;
            cmd1.Parameters.Add(paramC10);

            SqlParameter paramC11 = new SqlParameter();
            paramC11.ParameterName = "@Tadd3";
            paramC11.Value = TxtBxTroopAdd3.Text;
            cmd1.Parameters.Add(paramC11);

            SqlParameter paramC12 = new SqlParameter();
            paramC12.ParameterName = "@Tadd4";
            paramC12.Value = TxtBxTroopAdd4.Text;
            cmd1.Parameters.Add(paramC12);

            SqlParameter paramC13 = new SqlParameter();
            paramC13.ParameterName = "@Tadd5";
            paramC13.Value = TxtBxTroopAdd5.Text;
            cmd1.Parameters.Add(paramC13);

            SqlParameter paramC14 = new SqlParameter();
            paramC14.ParameterName = "@Tcity";
            paramC14.Value = TxtBxTroopCity.Text;
            cmd1.Parameters.Add(paramC14);

            SqlParameter paramC15 = new SqlParameter();
            paramC15.ParameterName = "@Tstate";
            paramC15.Value = TxtBxTroopState.Text;
            cmd1.Parameters.Add(paramC15);

            SqlParameter paramC16 = new SqlParameter();
            paramC16.ParameterName = "@Tzip";
            paramC16.Value = TxtBxTroopZip.Text;
            cmd1.Parameters.Add(paramC16);

            SqlParameter paramC17 = new SqlParameter();
            paramC17.ParameterName = "@Uid";
            paramC17.Value = TxtBxTroopUserID.Text;
            cmd1.Parameters.Add(paramC17);

            int added = 0;

            try
            {
                con1.Open();
                added = cmd1.ExecuteNonQuery();
                LblStat.Text += " Added Successfully " + added.ToString();
            }

            finally
            {
                con1.Close();
            }


        }
    }
}